
import React from "react";
import ModalComponent from "../Components/Model"
import { loginWithGoogle } from "../API/Auth";
import useCheckAuth from "../Hooks/useCheckAuth";
import Document from "../Components/Document";
// import Spinner from "../Components/Spinner";

const Docs: React.FC = () => {
  const handleLogin = () => {
    loginWithGoogle();
  };
  const { isAuthenticated, userData } = useCheckAuth();


  return (
  

        <div className="docs-container">
        {!isAuthenticated ? (
          <ModalComponent
            title="Login With Google"
            handleLogin={handleLogin}
          ></ModalComponent>
        
      ) : (
        <>
          <Document photoURL={userData?.photoURL} />
        </>
      )}
    </div>
  );
};

export default Docs;