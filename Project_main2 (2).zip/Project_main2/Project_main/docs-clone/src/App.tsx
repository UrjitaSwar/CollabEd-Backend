// import { useState } from 'react'

import './App.scss'
import Docs from "./Pages/Docs"

function App() {


  return (
    <>
      <Docs/>


    </>
  )
}

export default App
