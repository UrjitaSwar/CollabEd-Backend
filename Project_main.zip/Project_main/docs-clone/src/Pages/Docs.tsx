
import React from "react";
import ModalComponent from "../Components/Model"
import { loginWithGoogle } from "../API/Auth";
import useCheckAuth from "../Hooks/useCheckAuth";
import Document from "../Components/Document";
import Spinner from "../Components/Spinner";

const Docs: React.FC = () => {
  const handleLogin = () => {
    loginWithGoogle();
  };
  const { isAuthenticated, userData, loading } = useCheckAuth();
  if (loading) return <Spinner />;

  return (
    <>
      {!isAuthenticated ? (
        <div className="docs-container">
          <ModalComponent
            title="Login With Google"
            handleLogin={handleLogin}
          ></ModalComponent>
        </div>
      ) : (
        <>
          <Document photoURL={userData?.photoURL} />
        </>
      )}
    </>
  );
};

export default Docs;