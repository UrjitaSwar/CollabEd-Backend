interface TopbarProps {
    photoURL: string;

  }
  
  interface DropdownProps {
    children: React.ReactNode;
  }
  
  interface functionInterface {
    id: string;
    handleEdit: () => void;

  }
  
  interface setterDoc {
    setDocs: Function;
  }